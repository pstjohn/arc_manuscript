import numpy as np
import cPickle as pickle
import pylab as plt

from tools.Utilities import lighten_color

from tools.PlotOptions import PlotOptions, layout_pad
PlotOptions(uselatex=True)

# Load and process stochastic trajectories
data = pickle.load(open('figS2_stochastic_data.p', 'rb'))

control = data['control'].squeeze()
ts_cont = control[:,0]
ys_cont = control[:,1:].reshape((len(ts_cont), -1, 2))/data['vol']

pre = data['pre'].squeeze()
ts_pre = pre[:,0]
ys_pre = pre[:,1:].reshape((len(ts_pre), -1, 2))/data['vol']

pulse = data['pulse'].squeeze()
ts_pulse = pulse[:,0] + ts_pre[-1]
ys_pulse = pulse[:,1:].reshape((len(ts_pulse), -1, 2))/data['vol']

post = data['post'].squeeze()
ts_post = post[:,0] + ts_pulse[-1]
ys_post = post[:,1:].reshape((len(ts_post), -1, 2))/data['vol']

pulse = [ts_pulse[0], ts_pulse[-1]]

ts_pert = np.hstack([ts_pre[:-1], ts_pulse[:-1], ts_post])
ys_pert = np.vstack([ys_pre[:-1], ys_pulse[:-1], ys_post])

ts_cont = ts_cont - pulse[1]
ts_pert = ts_pert - pulse[1]


# Import deterministic model
from tools.Models.simplified_tysonmodel_2 import create_class
model = create_class()
model.average()

phis_cont = model._t_to_phi(ts_cont)
phis_pert = model._t_to_phi(ts_pert)

# Estimate decay parameter
from tools.Bioluminescence import Bioluminescence
cont_mean = ys_cont[:,:,1].mean(1) - model.avg[1]
cont_class = Bioluminescence(phis_cont, cont_mean)
cont_class.fit_sinusoid()
decay = cont_class.sinusoid_pars['decay']

# Estimate std parameter
# from tools.Amplitude import normalize
# phases_o = []
# phases_f = []
# for point in ys_pulse[0]: phases_o += [model.phase_of_point(point)[0]]
# for point in ys_post[0]: phases_f += [model.phase_of_point(point)[0]]
# phases_o = normalize(np.array(phases_o))
# phases_f = np.array(phases_f)




# Set up pdf-based model
from tools.Amplitude import Amplitude, gaussian_phase_distribution
ampl = Amplitude(model.model, model.paramset, model.y0)
par_ind = ampl.pdict['kt']
stateind = 1
param_pulse_creator = ampl._p_pulse_creator(1, -10., np.pi/4)
ampl.calc_pulse_responses(param_pulse_creator, trans_duration=4)

# set up initial population
mean = (model._t_to_phi(ts_pulse[-1]))%(2*np.pi)
std = 0.48 # from phases_o

test_population = gaussian_phase_distribution(mean, std, decay,
                                              invert_res=60)
ampl.calc_population_responses(test_population, tarc=False)
phis_det = ampl.comb_interp.ts
ts_det = ampl._phi_to_t(phis_det)

x_bar    = ampl.x_bar(phis_det)[:,stateind]
x_hat_ss = ampl.x_hat_ss(phis_det)[:,stateind]
x_hat    = ampl.x_hat(phis_det)[:,stateind]





# fig = plt.figure()
# ax = fig.add_subplot(111)
# 
# 
# ax.axvspan(pulse[0] - pulse[1], 0, color=lighten_color('y', 0.5))
# ax.plot(phis_cont, ys_cont[:,:,1].mean(1), 'k')
# ax.plot(phis_pert, ys_pert[:,:,1].mean(1), 'r')
# ax.plot(phis_pert, ys_pert[:,:,1], 'k', alpha=0.05, zorder=0)
# 
# fig = plt.figure()
# ax = fig.add_subplot(111)
# ax.plot(phis_det, x_bar   , 'k--')
# ax.plot(phis_det, x_hat_ss, 'b--')
# ax.plot(phis_det, x_hat   , 'r')






fig = plt.figure()
ax = fig.add_subplot(211)
ax.axvspan(model._t_to_phi(pulse[0] - pulse[1]), 0,
           color=lighten_color('y', 0.5))
ax.plot(phis_det, x_bar   , 'k-.', label=r'$\bar{x}(\hat{t})$')
ax.plot(phis_cont, ys_cont[:,:,1].mean(1), 'k',
        label='Unperturbed Population')

ax.plot(phis_det, x_hat   , 'r-.', label=r'$\hat{x}(\hat{t})$')
ax.plot(phis_pert, ys_pert[:,:,1].mean(1), 'r',
        label='Perturbed Population')

ax.set_xlim([-np.pi, 6*np.pi])
ax.set_xticks([-np.pi, 0, 2*np.pi, 4*np.pi, 6*np.pi])
ax.set_xticklabels([r'$-\pi$', r'$0$', r'$2\pi$', r'$4\pi$', r'$6\pi$'])

ax.legend(loc='best', ncol=2)

ax.set_ylabel(r'$Y$')

from tools.Utilities import color_range, PeriodicSpline
## Population plots
def expdist(x, d):
    return (np.exp(d*x) - 1)/(np.exp(d) - 1)

trange = 4*1.15*np.pi*expdist(np.linspace(0,1,4), 0.5) + np.pi/2
# trange = np.arange(4)*1.5*np.pi + 2*np.pi/4
crange = list(color_range(len(trange)+1))

phis = ampl.phis
perturbed_popul = ampl.phase_distribution.invert(phis, ampl.prc_single_cell)

ax_pop = fig.add_subplot(212, sharex=ax)

def plot_pop(population, phi_plot):
    pop = population(phi_plot).squeeze()
    interp = PeriodicSpline(ampl.phis, pop)
    phi_start = ampl.phis[pop.argmin()]
    interp_phis = np.linspace(phi_start, phi_start + 2*np.pi, num=100)
    y = interp(interp_phis)
    plot_ts = (interp_phis - phi_start - np.pi + phi_plot)
    phis_ind = np.abs(phis_pert - phi_plot).argmin()

    # check stochastic oscillator
    points = ys_pert[phis_ind,:,:]
    phases = []
    for point in points:
        phases += [model.phase_of_point(point)[0]]

    hist, bin_edges = np.histogram(phases, bins=15)
    bin_width = bin_edges[1] - bin_edges[0] 
    inds = bin_edges[:-1] < (phi_start)
    bins = bin_edges[:-1][~inds].tolist() + (bin_edges[:-1][inds] +
                                             bin_edges[-1]).tolist()

    hist = hist[~inds].tolist() + hist[inds].tolist()
    bins = np.array(bins) + phi_plot - np.pi - phi_start

    return plot_ts, y, phis_ind, hist/(225. * bin_width), bins, bin_width

t, y, phis_ind, hist, bins, bin_width = plot_pop(ampl.phase_distribution,
                                           -np.pi/2)
ax_pop.fill_between(t, 0, y, color=lighten_color(crange[0], 0.5))
ax_pop.plot(t, y, color=crange[0], lw=1.25)
ax.plot(phis_pert[phis_ind], ys_pert[phis_ind,:,1].mean(0), 'o',
        color=crange[0])
ax_pop.bar(bins, hist, bin_width, facecolor=lighten_color(crange[0], 0.5))

for phi_plot, color in zip(trange, crange[1:]):
    t, y, phis_ind, hist, bins, bin_width = plot_pop(perturbed_popul,
                                                     phi_plot)
    ax_pop.fill_between(t, 0, y, color=color, alpha=0.5)
    ax_pop.plot(t, y, color=color, lw=1.25)
    ax.plot(phis_pert[phis_ind], ys_pert[phis_ind,:,1].mean(0), 'o',
            color=color)
    ax_pop.bar(bins, hist, bin_width, facecolor=lighten_color(color, 0.5))



ax_pop.set_xlim([-np.pi, 6*np.pi])
ax_pop.set_xlabel(r'$\hat{t}$')
ax_pop.set_ylabel(r'$p(\theta, \hat{t})$')
fig.tight_layout(**layout_pad)


plt.show()
